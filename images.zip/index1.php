<?php header('Location: ./fog/index.php');?>
